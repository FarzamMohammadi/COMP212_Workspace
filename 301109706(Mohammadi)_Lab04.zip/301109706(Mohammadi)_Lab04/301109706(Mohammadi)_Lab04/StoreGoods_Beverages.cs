﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _301109706_Mohammadi__Lab04
{
    class StoreGoods_Beverages
    {
        public string BeverageName { get; set; }
        public string BeverageCategory { get; set; }
        public double BeveragePrice { get; set; }

    }
}
