﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _301109706_Mohammadi__Lab04
{
    class StoreGoods_Appetizers 
    {
        public string AppetizerName { get; set; }
        public string AppetizerCategory { get; set; }
        public double AppetizerPrice { get; set; }
/*
        public StoreGoods_Appetizers(string _name, string _cat, double _price)
        {
            AppetizerName = _name;
            AppetizerCategory = _cat;
            AppetizerPrice = _price;
        }*/
    }
}
