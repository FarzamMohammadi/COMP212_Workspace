﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _301109706_Mohammadi__Lab04
{
    class StoreGoods_MainCourses
    {
        public string MainCourseName { get; set; }
        public string MainCourseCategory { get; set; }
        public double MainCoursePrice { get; set; }

    }
}
